#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"

int main(int argc, char *argv[]) {

    if (argc < 2 || argc > 4) {
        printf("Error\n");
        return 1;
    }

    t_dict *dictionary;
	    if (argc == 2) {
		dictionary = parse_dictionary("en.dict");
    }
	else if(argc == 3) {
    		if (strcmp(argv[1], "en") == 0)
    			dictionary = parse_dictionary("en.dict");
    		else if (strcmp(argv[1], "de") == 0)
    			dictionary = parse_dictionary("de.dict");
    		else if (strcmp(argv[1], "lu") == 0)
    			dictionary = parse_dictionary("lu.dict");
    		else if (strcmp(argv[1], "fr") == 0)
    			dictionary = parse_dictionary("fr.dict");
    		else
    			dictionary = parse_dictionary(argv[1]);
    }
    else	
    {	
    	dictionary = parse_dictionary(argv[1]);
    }

    if (!dictionary) {
        printf("Dict Error\n");
        return 1;
    }

    char *endptr;
    unsigned long long number = strtoull(argv[argc - 1], &endptr, 10);
    if (*endptr != '\0') {
        printf("Error\n");
        return 1;
    }

    char *result = number_to_words(number, dictionary);
    if (result) {
        printf("%s\n", result);
        free(result);
    } else {
        printf("Dict Error\n");
    }

    free_dictionary(dictionary);
    return 0;
}

